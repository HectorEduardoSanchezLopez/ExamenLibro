class LibrosController < ApplicationController
 def index
   @libros = Libro.all
 end

 def show
  @libro = Libro.find(params[:id])
 end

 def new
  @libro = Libro.new
 end

 def edit
  @libro = Libro.find(params[:id])
 end 

 def create
  @libro = Libro.new(libro_params)

  if @libro.save
   redirect_to @libro
  else
   render :new
  end
 end

 def destroy
  @libro = Libro.find(params[:id])
  @libro.destroy
  redirect_to libros_path
 end

 def update
  # @libro.update_attributes({titulo: 'Nuevo Titulo'})
  @libro = Libro.find(params[:id])
  if @libro.update(libro_params)
  redirect_to @libro
  else
    render :edit
  end
 end

  private
  
  def libro_params
  params.require(:libro).permit(:titulo, :autor, :editorial, :num_pag)
  end
 end
